package com.springboothibernate.hinbernate.controller;

import com.springboothibernate.hinbernate.entity.PlayerHistory;
import com.springboothibernate.hinbernate.entity.RoomHistory;
import com.springboothibernate.hinbernate.repository.PlayerHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Controller
public class PlayerHistoryController {

}
