package com.springboothibernate.hinbernate;

import com.springboothibernate.hinbernate.entity.PlayerHistory;
import com.springboothibernate.hinbernate.entity.RoomHistory;
import com.springboothibernate.hinbernate.repository.PlayerHistoryRepository;
import com.springboothibernate.hinbernate.repository.RoomHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;

import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.Set;

@Controller
@SpringBootApplication
@Configuration
@EnableAutoConfiguration
public class HinbernateApplication implements CommandLineRunner{

	@Autowired
	private PlayerHistoryRepository playerHistoryRepository;

	@Autowired
	private RoomHistoryRepository roomHistoryRepository;


	public static void main(String[] args) {

		SpringApplication.run(HinbernateApplication.class, args);

	}

	@Override
	@Transactional
	public void run(String... strings) throws Exception {

/*		Set<RoomHistory> s1 = new HashSet<>();
		RoomHistory r1 = new RoomHistory(01, 123456799);
		RoomHistory r2 = new RoomHistory(02, 987654399);
		s1.add(r1);
		s1.add(r2);*/

		Set<RoomHistory> s11 = new HashSet<>();
		RoomHistory r3 = new RoomHistory(013, 1234567);
		RoomHistory r4 = new RoomHistory(025, 9876543);
		s11.add(r3);
		s11.add(r4);


/*		Set<PlayerHistory> s2 = new HashSet();
		PlayerHistory p1 = new PlayerHistory(11, "test01");
		PlayerHistory p2 = new PlayerHistory(22, "test02");
		s2.add(p1);
		s2.add(p2);*/

		Set<PlayerHistory> s26 = new HashSet();
		PlayerHistory p16 = new PlayerHistory(111, "test011");
		PlayerHistory p26 = new PlayerHistory(222, "test022");
		s26.add(p16);
		s26.add(p26);


		// 按理是存了2条数据的？？？？
		playerHistoryRepository.save(new PlayerHistory(11, "test01", s11)); // 应该表示 11号玩家，对应的战绩有01 房间号 9216543 以及 战绩02 房间号 123456

		roomHistoryRepository.save(new RoomHistory(01, 5698254, s26));// 表示 01战绩以及 9216543房间号对应的玩家id 是 11 和 12
	}
}
