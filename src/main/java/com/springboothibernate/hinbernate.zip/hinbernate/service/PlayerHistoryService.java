package com.springboothibernate.hinbernate.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class PlayerHistoryService{

}
