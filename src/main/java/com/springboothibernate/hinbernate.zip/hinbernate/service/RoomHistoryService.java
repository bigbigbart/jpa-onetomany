package com.springboothibernate.hinbernate.service;

import com.springboothibernate.hinbernate.repository.PlayerHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class RoomHistoryService {

    @Autowired
    private PlayerHistoryRepository playerHistoryRepository;
}
