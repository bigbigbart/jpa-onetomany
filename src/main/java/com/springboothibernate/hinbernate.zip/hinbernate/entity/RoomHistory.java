package com.springboothibernate.hinbernate.entity;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "RoomHistory")
@org.hibernate.annotations.Proxy(lazy = false)
public class RoomHistory implements java.io.Serializable{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private int id;

    private int historyId;


    private int roomId;
    private int hostId;
    private String playway;
    private Date date;

    @ManyToMany
    @Cascade(org.hibernate.annotations.CascadeType.ALL)
    @JoinTable(name="RPHistory", joinColumns={@JoinColumn(referencedColumnName="roomId")}
            , inverseJoinColumns={@JoinColumn(referencedColumnName="userId")})
    private Set<PlayerHistory> playerHistories;


    public RoomHistory() {
    }

    public RoomHistory(int historyId, int roomId) {
        this.historyId = historyId;
        this.roomId = roomId;
    }

    public RoomHistory(int historyId, int roomId, Set<PlayerHistory> playerHistories) {
        this.historyId = historyId;
        this.roomId = roomId;
        this.playerHistories = playerHistories;
    }

    public int getHistoryId() {
        return historyId;
    }

    public void setHistoryId(int historyId) {
        this.historyId = historyId;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public int getHostId() {
        return hostId;
    }

    public void setHostId(int hostId) {
        this.hostId = hostId;
    }

    public String getPlayway() {
        return playway;
    }

    public void setPlayway(String playway) {
        this.playway = playway;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Set<PlayerHistory> getPlayerHistories() {
        return playerHistories;
    }

    public void setPlayerHistories(Set<PlayerHistory> playerHistories) {
        this.playerHistories = playerHistories;
    }
}
