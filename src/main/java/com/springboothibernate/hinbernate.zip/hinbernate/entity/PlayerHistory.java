package com.springboothibernate.hinbernate.entity;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "PlayerHistory")
@org.hibernate.annotations.Proxy(lazy = false)
public class PlayerHistory implements java.io.Serializable{
    private static final long serialVersionUID = 1115593425069549681L;


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private int id;

    private int userId;
    private String userName;
    private int isBanker;
    private int betRatio;
    private String handCards;
    private String lastCard;
    private int score;
    private String type;

    @ManyToMany(mappedBy = "playerHistories")
    @Cascade(org.hibernate.annotations.CascadeType.ALL)
    private Set<RoomHistory> roomHistories;

    public PlayerHistory() {
    }

    public PlayerHistory(int userId) {
        this.userId = userId;
    }

    public PlayerHistory(int userId, String userName) {
        this.userId = userId;
        this.userName = userName;
    }

    public PlayerHistory(int userId, String userName, Set<RoomHistory> roomHistories) {
        this.userId = userId;
        this.userName = userName;
        this.roomHistories = roomHistories;
    }

    public PlayerHistory(int userId, Set<RoomHistory> roomHistories) {
        this.userId = userId;
        this.roomHistories = roomHistories;
    }


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getBetRatio() {
        return betRatio;
    }

    public void setBetRatio(int betRatio) {
        this.betRatio = betRatio;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHandCards() {
        return handCards;
    }

    public void setHandCards(String handCards) {
        this.handCards = handCards;
    }

    public String getLastCard() {
        return lastCard;
    }

    public void setLastCard(String lastCard) {
        this.lastCard = lastCard;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIsBanker() {
        return isBanker;
    }

    public void setIsBanker(int isBanker) {
        this.isBanker = isBanker;
    }

    public Set<RoomHistory> getRoomHistories() {
        return roomHistories;
    }

    public void setRoomHistories(Set<RoomHistory> roomHistories) {
        this.roomHistories = roomHistories;
    }

    @Override
    public String toString() {
        return "PlayerHistory{" +
                "id=" + id +
                ", userId='" + userId + '\'' +
                ", userName='" + userName + '\'' +
                ", isBanker=" + isBanker +
                ", betRatio='" + betRatio + '\'' +
                ", handCards='" + handCards + '\'' +
                ", lastCard='" + lastCard + '\'' +
                ", score='" + score + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
