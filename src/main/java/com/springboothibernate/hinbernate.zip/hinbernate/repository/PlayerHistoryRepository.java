package com.springboothibernate.hinbernate.repository;

import com.springboothibernate.hinbernate.entity.PlayerHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public  interface PlayerHistoryRepository extends JpaRepository<PlayerHistory, Integer> {

}
